import sqlite3
import os

class DBManager:

    def __init__(self, db_name='ecotech.db'):
        self.db_name = db_name

    def conectar(self):
        try:
            conexion = sqlite3.connect(self.db_name)
            return conexion
        except sqlite3.Error as e:
            print(f"Error crítico al conectar a la BD: {e}")
            return None

    def inicializar_tablas(self):
        # Script SQL para crear las tablas necesarias
        sql_script = """
        -- Tabla Departamentos
        CREATE TABLE IF NOT EXISTS departamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            gerente TEXT
        );

        -- Tabla Proyectos
        CREATE TABLE IF NOT EXISTS proyectos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            fecha_inicio TEXT
        );

        -- Tabla Empleados (Con FK a Departamentos)
        CREATE TABLE IF NOT EXISTS empleados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            rut TEXT UNIQUE NOT NULL,
            direccion TEXT,
            telefono TEXT,
            email TEXT,
            fecha_contrato TEXT,
            salario REAL,
            departamento_id INTEGER,
            FOREIGN KEY(departamento_id) REFERENCES departamentos(id)
        );

        -- Tabla Asignaciones (Relación Muchos a Muchos: Empleados <-> Proyectos)
        CREATE TABLE IF NOT EXISTS asignaciones (
            empleado_id INTEGER,
            proyecto_id INTEGER,
            FOREIGN KEY(empleado_id) REFERENCES empleados(id),
            FOREIGN KEY(proyecto_id) REFERENCES proyectos(id),
            PRIMARY KEY (empleado_id, proyecto_id)
        );
        """

        # Conexión con el método (self.conectar)
        conn = self.conectar()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.executescript(sql_script)
                conn.commit()
                print("Base de datos iniciada y tablas creadas exitosamente.")
            except sqlite3.Error as e:
                print(f"Error al inicializar tablas: {e}")
            finally:
                conn.close()


# Instancia global para usar el proyecto
db = DBManager()