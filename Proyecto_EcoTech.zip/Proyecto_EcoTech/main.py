import sys
from database.conexion import db
from models.entidades import Empleado, Departamento, Proyecto

# Función para limpiar y esperar
def pausa():
    input("Presione Enter para continuar...")

def menu_principal():
    # Inicia la BD
    db.inicializar_tablas()

    while True:
        print("\n" + "="*40)
        print("   SISTEMA DE GESTIÓN ECO-TECH   ")
        print("="*40)
        print("1. Gestionar Empleados")
        print("2. Gestionar Departamentos")
        print("3. Gestionar Proyectos")
        print("4. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            sub_menu_empleados()
        elif opcion == '2':
            sub_menu_departamentos()
        elif opcion == '3':
            sub_menu_proyectos()
        elif opcion == '4':
            print("Saliendo del programa...")
            sys.exit()
        else:
            print("Opción no válida. Intente nuevamente.")
            pausa()
            
def sub_menu_empleados():
    while True:
        print("\n--- Gestión de Empleados ---")
        print("1. Agregar Empleado (CREATE)")
        print("2. Listar Empleados (READ)")
        print("3. Actualizar salario (UPDATE)")
        print("4. Eliminar Empleado (DELETE)")
        print("5. Volver al menú principal")

        op = input("Seleccione una opción: ")

        if op == '1':
            try:
                print("\nIngrese los datos del nuevo empleado:")
                nombre = input("Nombre: ")
                rut = input("RUT: ")
                direccion = input("Dirección: ")
                email = input("Email: ")
                telefono = input("Teléfono: ")
                fecha_contrato = input("Fecha de Contrato (YYYY-MM-DD): ")
                salario = float(input("Salario: "))

                print("\nDepartamentos disponibles:")
                for d in Departamento.listar_todos():
                    print(f"ID {d['id']}: {d['nombre']}")
                input_depto = input("ID del Departamento asignado (Enter para ninguno): ")

                if input_depto.strip(): # Si el usuario escribió algo (no está vacío)
                    depto_id = int(input_depto)
                else:
                    depto_id = None

                nuevo_emp = Empleado(nombre, rut, direccion, email, telefono, fecha_contrato, salario, depto_id)
                nuevo_emp.guardar()
            except ValueError as e:
                print(f"Error en los datos ingresados: {e}")
        
        elif op == '2':
            print("\nLista de Empleados:")
            lista = Empleado.listar_todos()
            if not lista:
                print("No hay empleados registrados.")
            for emp in lista:
                #Uso del polimorfismo y getter de salario
                print(f"{emp.mostrar_informacion()}, Salario: ${emp.salario}")
        
        elif op == '3':
            try:
                id_emp = int(input("Ingrese el ID del empleado a actualizar: "))
                monto = float(input("Ingrese el nuevo salario: "))
                Empleado.actualizar_salario(id_emp, monto)
            except ValueError as e:
                print(f"Error en los datos ingresados: {e}")
        
        elif op == '4':
            try:
                id_emp = int(input("Ingrese el ID del empleado a eliminar: "))
                Empleado.eliminar(id_emp)
            except ValueError as e:
                print(f"Error en los datos ingresados: {e}")

        elif op == '5':
            break

        pausa()

def sub_menu_departamentos():
    while True:
        print("\n--- Gestión de Departamentos ---")
        print("1. Agregar Departamento (CREATE)")
        print("2. Listar Departamentos (READ)")
        print("3. Volver al menú principal")

        op = input("Seleccione una opción: ")

        if op == '1':
            nombre = input("Nombre del Departamento: ")
            gerente = input("Nombre del Gerente: ")
            d = Departamento(nombre, gerente)
            d.guardar()
        elif op == '2':
            print("\nLista de Departamentos:")
            lista = Departamento.listar_todos()
            for d in lista:
                print(f"ID: {d['id']} | {d['nombre']}")
        pausa()
    
def sub_menu_proyectos():
    print("\n--- Gestión de Proyectos ---")
    print("1. Crear Proyecto (CREATE)")
    print("2. Volver al menú principal")
    op = input("Seleccione una opción: ")

    if op == '1':
        nom = input("Nombre del Proyecto: ")
        desc = input("Descripción: ")
        fecha_ini = input("Fecha de Inicio (YYYY-MM-DD): ")
        p = Proyecto(nom, desc, fecha_ini)
        p.guardar()
    pausa()

if __name__ == "__main__":
    menu_principal()