from .clases_base import Persona
from .entidades import Empleado, Departamento, Proyecto
# Etapa 2
from .servicios import GestorIndicadores