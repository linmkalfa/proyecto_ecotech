from .clases_base import Persona
from .entidades import Empleado, Departamento, Proyecto